#include "a7.h"

void qInitialize(QUEUE* q){
q->size=0;
}
