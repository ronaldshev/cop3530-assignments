#include "a7.h"

VERTEX* getFirst(QUEUE* q){
return q->data[0];
}
