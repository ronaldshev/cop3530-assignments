#include "a7.h"

void sInitialize(STACK* stack){
stack->size=0;
}
