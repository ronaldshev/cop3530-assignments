#include "a7.h"

void pop(STACK* stack){
if(stack->size>0){
stack->size--;
}
}
